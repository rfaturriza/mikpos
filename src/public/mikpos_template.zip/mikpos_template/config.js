var config = {
    "hotspotname":  "HOTSPOT.NET",
    "runningtext":  "Selamat datang di layanan kami, nikmati layanan unlimited tanpa kuota!",
    "rotuerid":     "123/123", // router id yang di dapatkan dari mikpos.space
    "siteUrl":     "https://mikpos.space/" // ganti dengan url website anda
};
